import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(foregroundColor: Colors.black12),
        ),
      ),
      home: Scaffold(
        backgroundColor: Colors.white,
        body: Center(
          child: Column(
            children: [
              SizedBox(height: 160),
              Image.asset(
                "assets/logo.png",
                height: 120,
                width: 120,
                fit: BoxFit.cover,
              ),
              SizedBox(height: 120),
              TextFormField(
                  decoration: InputDecoration(
                      icon: Icon(Icons.person),
                      border: OutlineInputBorder(),
                      hintText: "Masukkan Email",
                      labelText: "Email")),
              SizedBox(height: 10),
              TextFormField(
                decoration: InputDecoration(
                    icon: Icon(Icons.key),
                    border: OutlineInputBorder(),
                    hintText: "Masukkan Password",
                    labelText: "Password"),
              ),
              SizedBox(height: 30),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 80,
                  vertical: 5,
                ),
                child: Row(
                  children: [
                    new SizedBox(
                      width: 250.0,
                      height: 40.0,
                      child: FilledButton(
                        style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.all<Color>(Colors.blue),
                        ),
                        child: Text('Log In'),
                        onPressed: () {},
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 80,
                  vertical: 5,
                ),
                child: Row(
                  children: [
                    new SizedBox(
                      width: 250.0,
                      height: 40.0,
                      child: FilledButton(
                        style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.all<Color>(Colors.blue),
                        ),
                        child: Text('Sign In'),
                        onPressed: () {},
                      ),
                    ),
                  ],
                ),
              ),
              Image.asset(
                "assets/img-1.png",
                height: 244,
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.cover,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
